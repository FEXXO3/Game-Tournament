---
name: Apex Arena System
colors:
  surface: '#10131a'
  surface-dim: '#10131a'
  surface-bright: '#363940'
  surface-container-lowest: '#0b0e14'
  surface-container-low: '#191c22'
  surface-container: '#1d2026'
  surface-container-high: '#272a31'
  surface-container-highest: '#32353c'
  on-surface: '#e1e2eb'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#e1e2eb'
  inverse-on-surface: '#2e3037'
  outline: '#849495'
  outline-variant: '#3b494b'
  surface-tint: '#00dbe9'
  primary: '#dbfcff'
  on-primary: '#00363a'
  primary-container: '#00f0ff'
  on-primary-container: '#006970'
  inverse-primary: '#006970'
  secondary: '#dcb8ff'
  on-secondary: '#480081'
  secondary-container: '#7701d0'
  on-secondary-container: '#dcb7ff'
  tertiary: '#d8ffe7'
  on-tertiary: '#003824'
  tertiary-container: '#65f2b5'
  on-tertiary-container: '#006d4a'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#7df4ff'
  primary-fixed-dim: '#00dbe9'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f54'
  secondary-fixed: '#efdbff'
  secondary-fixed-dim: '#dcb8ff'
  on-secondary-fixed: '#2c0051'
  on-secondary-fixed-variant: '#6700b5'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#10131a'
  on-background: '#e1e2eb'
  surface-variant: '#32353c'
typography:
  display-xl:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: 0em
  bracket-score:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 24px
    letterSpacing: 0.04em
  body-lg:
    fontFamily: Outfit
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Outfit
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Outfit
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-badge:
    fontFamily: Space Grotesk
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
  label-mono:
    fontFamily: Space Grotesk
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.75rem
  gutter-md: 1rem
  margin: 1rem
  margin-md: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
---

## Brand & Style

The design system establishes a high-performance, dark-mode competitive ecosystem tailored for eSports tournament organizers, team captains, and players. The aesthetic fuses **Cyber-Athletics** and **Precision Brutalism**—eliminating frivolous retro tropes in favor of razor-sharp ergonomic clarity, cold-luminescent lighting, and tactical density.

### Key Visual Pillars
- **Championship Authority:** Dark obsidian tiers provide a non-distracting bedrock where high-stakes match data, brackets, and telemetry take absolute focus.
- **Electric Feedback:** Laser-focused neon hues signal live match states, victor statuses, and real-time confirmations without visual fatigue.
- **Tactical Geometry:** Subtle 45-degree chamfers, micro-notches, and precise hair-thin structural lines convey competitive hardware and HUD telemetry.
- **Tournament Ergonomics:** Designed for single-thumb execution on mobile screens under tense competitive environments (stage lighting, quick roster check-ins, instant score reporting).

## Colors

The palette is engineered exclusively around deep-space canvas values overlaid with ultra-saturated chromatic accents. All colors meet strict contrast ratios against the dark foundation for tournament readability.

### Canvas & Surfaces
- **Canvas Base (`#0B0E14`):** Pure background layer preventing OLED battery bleed and establishing visual zero.
- **Surface Layer 1 (`#121824`):** Cards, bracket containers, and bottom navigation sheets.
- **Surface Layer 2 (`#1A2234`):** Elevated modals, match item rows, and interactive pressed states.
- **Surface Highlight (`#222D42`):** Stroke borders, divider separators, and inactive slot outlines.

### Chromatic Signals
- **Neon Cyan (`#00F0FF`):** Primary tournament actions, live lobbies, head-to-head vs badges, and active check-ins. Glow accent token: `rgba(0, 240, 255, 0.25)`.
- **Electric Violet (`#8A2BE2` / `#7928CA`):** Bracket progressions, tier hierarchies (Diamond/Challenger/Master), playoff indicators, and prize pool emphasis.
- **Neon Emerald (`#10B981`):** Match confirmations, qualified brackets, ready-checks, and win states.
- **Crimson Alert (`#EF4444`):** Disqualifications, forfeits, penalty reports, and elimination flags.
- **Text Primary (`#F8FAFC`):** Display scores, team rosters, and titles.
- **Text Secondary (`#94A3B8`):** Timestamps, platform tags, seed numbers, and server regions.

## Typography

The type system contrasts technical geometry with extreme interface legibility:
- **Headlines & Brackets (`Space Grotesk`):** Delivers sharp, angular terminals and technological precision suited for bracket seeds, match scores, kill counters, and division headers.
- **Body & Controls (`Outfit`):** Clean, geometric sans-serif offering maximum scan-speed for tournament rules, match chat, rosters, and registration inputs.
- **Uppercase Hierarchy:** Micro-labels, match seeds, tags, and status badges are rendered strictly in uppercase with positive letter tracking (+0.08em to +0.1em) to emulate physical HUD readouts.

## Layout & Spacing

A compact 4-column layout model tuned for 360px–430px mobile screen widths, expanding seamlessly into 8 columns on foldable devices and tablets.

- **Vertical Rhythm:** Root baseline based on a 4px/8px modular cadence. Touch targets across matches and bracket navigation enforce a strict minimum height of 48px.
- **Tournament Canvas Margin:** Outer viewport margins are pinned at 16px (`margin: 1rem`) on phone widths, preserving precious horizontal space for bracket trees and split scoreboards.
- **Bracket Viewport:** Tournament tree screens bypass standard page padding horizontally, introducing an infinite horizontal pan canvas with pinned HUD controls top and bottom.
- **Component Padding:** Cards and match tiles utilize dense vertical padding (`space-sm` / `space-md`) paired with structured horizontal padding (`space-lg`) to balance dense match data with tap accuracy.

## Elevation & Depth

Depth is defined by dark tonal layering, crisp 1px structural borders, and targeted luminescent backdrops rather than conventional drop shadows.

### Surface Elevation Levels
- **Level 0 (Backdrop):** `#0B0E14` (Infinite canvas).
- **Level 1 (Structural Cards & Brackets):** `#121824` with a 1px solid border of `#222D42`.
- **Level 2 (Active/Hover/Highlight):** `#1A2234` with a 1px solid border of `rgba(0, 240, 255, 0.3)`.
- **Level 3 (Overlays, Bottom Sheets & Modals):** `#161F2E` with a top highlight border `linear-gradient(90deg, #00F0FF, #8A2BE2)` at 1.5px and an ambient shadow `0 16px 32px rgba(0, 0, 0, 0.6)`.

### Chromatic Glows
Interactive game states use colored ambient halos:
- **Live Match Pulsing Glow:** `0 0 16px rgba(0, 240, 255, 0.25)`.
- **Grand Finals / High Tier Glow:** `0 0 20px rgba(138, 43, 226, 0.3)`.
- **Victory Glow:** `0 0 16px rgba(16, 185, 129, 0.25)`.

## Shapes

The system relies on compact, disciplined rounding (level 1: 4px base radius) paired with sharp angled accents to reflect competitive gaming gear.

- **Standard Containers:** Cards, roster entries, and input fields utilize `rounded-sm` (4px) to retain an architectural, digital edge.
- **Corner Notches / Chamfers:** Critical match-card headers, bracket badges, and primary action buttons feature 4px/45-degree corner clips on top-right or diagonal opposite corners (`clip-path: polygon(...)`).
- **Tactical Pills:** Exclusively reserved for live tournament status pills (e.g., `🔴 LIVE`, `CHECK-IN`) using a 9999px fully rounded pill for rapid scanning against angular content.

## Components

### 1. Primary Action Buttons
- **Neon Cyan Apex Button:** Height 48px, background `#00F0FF`, text `#0B0E14` (`Space Grotesk`, 700 weight, uppercase). Clipped 6px top-right corner. Active state casts a cyan halo `0 0 18px rgba(0, 240, 255, 0.45)`.
- **Secondary Ghost Button:** Height 48px, background `rgba(34, 45, 66, 0.4)`, border 1px solid `#222D42`, text `#F8FAFC`. Active state snaps border to `#00F0FF`.

### 2. Match & Bracket Cards
- **Structure:** Surface `#121824`, border 1px solid `#222D42`. Divided into two team rows: seed number, team crest (24x24px), team abbreviation (`#F8FAFC`), and score block (`Space Grotesk`, bold).
- **Winner State:** The winning team row receives an accent border-left (3px solid `#10B981`) and bright text; the defeated team dims to opacity 0.45.
- **Live Indicator:** Border pulses with a cyan shimmer gradient; central VS indicator shifts to an animated `LIVE` badge.

### 3. Status Badges & Chips
- **Geometry:** Height 22px, border-radius 2px, font size 10px, bold tracking +0.1em.
- **Registration Open:** Background `rgba(0, 240, 255, 0.12)`, border 1px solid `rgba(0, 240, 255, 0.4)`, text `#00F0FF`.
- **Bracket Tier (Challenger/Pro):** Background `rgba(138, 43, 226, 0.15)`, border 1px solid `rgba(138, 43, 226, 0.5)`, text `#C084FC`.
- **Eliminated / DQ:** Background `rgba(239, 68, 68, 0.12)`, border 1px solid `rgba(239, 68, 68, 0.4)`, text `#EF4444`.

### 4. Input Fields & Search Bars
- **Surface:** `#0E131D`, border 1px solid `#222D42`, text `#F8FAFC`, placeholder `#64748B`.
- **Focus State:** 1px solid `#00F0FF`, subtle inner glow `inset 0 0 8px rgba(0, 240, 255, 0.1)`.
- **Height:** 48px for thumb comfort. Clear icon button integrated on the trailing edge.

### 5. Checkboxes & Radio Selection
- **Form:** 20x20px angular checkbox with 2px radius. Inactive: border 1.5px solid `#334155`, background transparent.
- **Checked:** Background `#00F0FF`, border 1.5px solid `#00F0FF`, icon checkmark in `#0B0E14`.

### 6. Tournament Specifics: Bracket Connectors & HUD Dock
- **Bracket Connector Lines:** 2px solid `#222D42`. Resolved matchups highlight the advancing branch in `#00F0FF` or `#8A2BE2`.
- **Bottom Navigation Dock:** Floating HUD bar `#121824` with top border 1px `rgba(255, 255, 255, 0.08)`, frosted backdrop filter (blur 16px). Active screen icon features a micro cyan glow point beneath it.